# 39aigame 更新日志

## v39.0 (2026-10-05)

### 军师控制优化

#### 修复
- **军师不工作**: 修复 `should_advice()` 时间基准错误（`pygame.time.get_ticks()` → `time.time()`）
- **边界卡住**: 修复主公频繁卡在地图边界的问题
- **指令stuck**: 修复军师指令长时间不更新的问题
- **Camp属性错误**: 修复 `Camp` 对象没有 `rect` 属性的崩溃问题

#### 优化
- **建议频率**: 从每2秒降低到每5秒，提高单条建议权重
- **LLM超时**: 从10秒延长到20秒
- **Token数**: 从128减少到64，加快响应
- **温度**: 从0.5降低到0.3，提高确定性

#### 新增
- **后处理修正**: 添加 `_post_process_cmd()` 方法，进行边界检测和修正
- **边界检测**: 如果主公靠近边界（<150像素），强制向中心移动
- **角落处理**: 如果主公在角落，向中心对角线移动
- **增强提示词**: 添加边界警告和中心区域引导
- **调试信息**: 添加边界检测和修正的调试输出
- **fallback修正**: LLM失败时的fallback指令也进行边界修正
- **超时保护**: 添加 `llm_pending` 30秒超时保护，防止卡住

#### 改进
- **传递游戏状态**: 在 `tank_battle_deluxe.py` 中传递完整 `_game_state` 给军师
- **边界余量**: 从100像素增大到150像素
- **回防阈值**: 从大营HP<30%降低到<50%，更积极回防

### 文件变更

#### 修改
- `src/channels.py` — AdvisorChannel 类优化
- `src/tank_battle_deluxe.py` — 传递 game_state 给军师

#### 新增文档
- `docs/v39.0_军师控制优化详解.md` — 优化详解
- `docs/v39.0_部署指南.md` — 部署指南
- `docs/v39.0_游戏逻辑详解.md` — 游戏逻辑详解

## v36.0 (2026-10-05)

### 架构重构
- 巨石拆分: 主文件从4494行减少到2552行
- 新增 directors.py、channels.py、world_api.py
- 统一LLM出口: llm_client.py
- 数据统一: stats_view.py

### 新增功能
- 高速数据库: highspeed_db.py
- 战术进化: tactics_evolution.py
- 强制多样化: tactics_diversity_enforcer.py
- 战场记录: battle_recorder.py

### 修复
- SQLite跨线程静默失败
- 新旧API断裂
- urllib NameError
- 多样化器放行漏洞
- 路径跨项目污染

## v33.0 (2025-10-03)

### 初始版本
- 坦克大战基础玩法
- AI导演系统
- 军师对话系统
- 36计选计系统
